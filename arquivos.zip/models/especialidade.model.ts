export type Especialidade = {
    id: number;
    nome: string;
}