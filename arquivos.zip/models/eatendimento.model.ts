export enum EAtendimento {
    CONSULTA = 'CONSULTA',
    RETORNO = 'RETORNO',
    EXAME = 'EXAME'
}
