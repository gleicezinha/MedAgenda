export type Usuario = {
    id: number;
    nomeCompleto: string;
    nomeUsuario: string;
    cpf: string;
    email: string;
    telefone: string;
    senha: string;
    papel: string;
    ativo: boolean;
}