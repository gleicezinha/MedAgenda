import { Component } from '@angular/core';

@Component({
    selector: 'app-especialidade',
    imports: [],
    templateUrl: './especialidade.component.html',
    styleUrl: './especialidade.component.scss'
})
export class EspecialidadeComponent {

}
