import { Component } from '@angular/core';

@Component({
    selector: 'app-medico',
    imports: [],
    templateUrl: './medico.component.html',
    styleUrl: './medico.component.scss'
})
export class MedicoComponent {

}
